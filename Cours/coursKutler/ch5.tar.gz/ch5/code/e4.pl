schema([a,b,c]).
fds1([[[a],[b,c]], [[b],[a]]]).
fds2([[[a],[b]], [[a],[c]]]).
