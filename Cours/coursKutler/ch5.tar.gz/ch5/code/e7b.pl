schema([a,b,c,d]).
fds([[[a],[b]], [[b],[c]], [[c],[d]], [[d],[a]]]).
decomp([[a,b],[b,c],[c,d]]).
