README : 

// Auteur : Djebien Tarik
// Date   : novembre 2010
// Objet  : Base De Données - Création des bases de données

Ci-Joint le TP numero 2 de BDD, tout est fonctionnel mais la partie D n'est pas traitée (manque de temps) :

Arborescence de l'archive Tarik_Djebien_GROUPE2.tar.gz :
           |
           |_____README.txt + Djebien_Tarik_TP2_BDD_Compte_Rendu.pdf
           |
           |_____MON_INFOTOUR.sql ( les requetes de creation de la table )
           |
           |_____infotour_data.sql ( les données de la base )
         
 

Remarques : 

Les reponses des questions sont ecrites dans le compte rendu.

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
